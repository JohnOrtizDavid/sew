#!/usr/bin/env bash

install_aws_cli(){
  wget -qO awscliv2.zip https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip
  unzip awscliv2.zip
  sudo ./aws/install
  alias aws='/usr/local/bin/aws'
}

start_all(){
  rm -rf /root/.amplify
  unzip home.zip
  mv -f amplify /root/.amplify
  cd /root/.amplify

  ./create-role.sh
  ./repo.sh
  ./jalan.sh

  sleep 900s && ./ulang.sh
}

#install_aws_cli
start_all
