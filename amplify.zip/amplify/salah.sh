#!/usr/bin/env bash

for i in {1..16}
  now=$(sed -n ${i}p region.txt)
  aws configure set region $now
  ./rebuild.sh
  echo "==> region $now"
done
