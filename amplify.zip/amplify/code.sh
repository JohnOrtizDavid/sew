#!/usr/bin/env bash

cd test
rm -rf .git
git init
git add .
git commit -m "web app"
git branch -m master
git status
git config --global credential.helper '!aws codecommit credential-helper $@'
git config --global credential.UseHttpPath true

push_repo(){
  git remote remove codecommit
  REPO=$(aws codecommit get-repository --repository-name $1 \
    --query 'repositoryMetadata.cloneUrlHttp'| tr -d '"' 2> /dev/null)
  git remote add codecommit $REPO
  git push -f codecommit master
}

push_repo test
push_repo test1
push_repo test2
