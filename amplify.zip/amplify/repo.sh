#!/usr/bin/env bash

create_repo(){
  aws codecommit create-repository --repository-name $1 > /dev/null 2>&1
}

for i in (1..16); do
  now=$(sed -n ${i}p region.txt)
  aws configure set region $now
  create_repo test
  create_repo test1
  create_repo test2
  ./code.sh
  echo "==> region $now"
done
