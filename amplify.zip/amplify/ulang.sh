#!/usr/bin/env bash

while true; do
  for i in {1..16}
    now=$(sed -n ${i}p region.txt)
    aws configure set region $now
    ./restart.sh
    echo "==> region $now"
  done
  ./quota.sh
  sleep 900s
done
