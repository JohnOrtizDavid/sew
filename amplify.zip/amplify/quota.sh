#!/usr/bin/env bash

for i in {1..16}
  now=$(sed -n ${i}p region.txt)
  aws configure set region $now
  QUOTA=$(aws service-quotas get-service-quota --service-code ec2 --quota-code L-1216C47A --query 'Quota.Value')
  echo "$QUOTA == region $now"
done
